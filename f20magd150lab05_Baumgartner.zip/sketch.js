var x = 45;
var y = 440;
var w = 35;
var h = 30;
var circleX = 45;
var circleY = 378;
var radius = 20;
var pumpkinX = 125;
var pumpkinY = 240;
var speed = 2;
var speed1 = 2;

function setup() {
  createCanvas(500, 500);
}


function draw() {
    background(190);
  
push();
  strokeWeight(3)
  fill(255);
  point(30,400);
  pop();
  
      push(); //TV
      stroke(51,58,64);
      strokeWeight(5);
      fill(10,11,13);
      rectMode(CENTER);
      rect(250,255,300,200);
      pop();
    

   
  push() //remote
  stroke(56,61,61);
strokeWeight(2);
fill(10,11,13);
rect(20,350,50,120);
  pop();
  
    push(); //turns on tv
  fill(63,72,79);
  rectMode(CENTER);
  rect(x,y,w,h);
  pop();
  

   if(mouseIsPressed){
  if(mouseX>x && mouseX <x+w && mouseY>y && mouseY <y+h){
        push(); //TV
      stroke(51,58,64);
      strokeWeight(5);
      fill(128,48,32);
      rectMode(CENTER);
      rect(250,255,300,200);
      pop();
  }
   }

  push(); // hanging support for light bulb 
  stroke(0);
  strokeWeight(3)
  line(250,0,250,90);
  pop()
  
  push(); // base for table
  fill(79,50,17);
  rect(100,390,300,150);
  pop()
  
push(); // table insides and top
fill(51,32,11);
  strokeWeight(5)
  rect(130,410,100,100);
  rect(270,410,100,100);
  line(90,390,410,390);
  pop();
  
  push(); // plant pot
  stroke(161,99,42);
  strokeWeight(3);
  fill(203,124,80);
  rect(160,470,40,50);
  line(155,470,205,470);
  pop();
  
  push() // grass 
  strokeWeight(3);
  stroke(53,94,26);
  line(161,467,161,450);
  line(165,467,165,440);
  line(168,467,169,435);
  line(171,467,174,441);
  line(175,467,178,445);
  line(180,467,185,435);
  line(184,467,189,440);
  line(189,467,190,446);
  line(194,467,193,445);
  line(198,467,195,439);
  pop()

 push(); // first book
  stroke(110,123,138);
  strokeWeight(5);
  fill(161,178,218);
  rect(275,450,20,50);
  pop();
  
  push(); //seconed book
  stroke(106,116,138);
  strokeWeight(5);
  fill(129,119,158);
  rect(300,440,25,80);
  pop()
  
  push(); //third book
  stroke(138,114,130);
  strokeWeight(5);
  fill(181,150,171);
  rect(330,445,15,80);
  pop();
  
  push(); //fourth book
  stroke(128,100,98);
  strokeWeight(5);
  fill(148,116,114);
  rect(350,460,15,80);
  pop();
  
  push(); //light bulb 
  strokeWeight(2);
  fill(237,231,231);
  ellipse(250,100,30,30);
  pop()
 
      push(); 
  fill(63,72,79);
  ellipseMode(RADIUS);
  ellipse(circleX,circleY,radius,radius);
  pop();
   
      if (dist(mouseX, mouseY, circleX, circleY) < radius) {
  push(); // turn on my light 
      stroke(247,246,179);
      strokeWeight(3)
      ellipse(250,100,30,30);
      pop();
}
  
  push(); // the little DVD symbol that bounces around, but a circle
  ellipseMode(CENTER);
  strokeWeight(3);
  fill(10,11,13);
  ellipse(pumpkinX,pumpkinY,40,40);
  pop();
  
  pumpkinX = pumpkinX + speed;
  pumpkinY = pumpkinY + speed1;
  
  if(pumpkinX >= 380){
    speed = -2;
  } if (pumpkinX <= 120){
    speed = +2;
  } if (pumpkinY >= 330){
    speed1 = -2;
  } if (pumpkinY <= 180){
    speed1 = +2;
  }
  
  
  text("Light",33,380)
  text("PWR", 30,440);



   }




  
  








